# Dimmer

App Android che scurisce lo schermo oltre il minimo di sistema, pensata per display AMOLED
(`com.mdovideo.dimmer`, Kotlin + Jetpack Compose, Material 3: colori dinamici, tema chiaro/scuro, nero vero su AMOLED).

## Come funziona
- Un servizio in primo piano aggiunge una finestra nera a tutto schermo (`TYPE_APPLICATION_OVERLAY`),
  non toccabile: i tocchi passano all'app sotto.
- Slider di intensità 10–80%. Il tetto a 80% è voluto: da Android 12 le finestre sopra l'80% di opacità
  bloccano i tocchi verso le app sotto.
- Opzione "Luminosità al minimo": imposta anche `screenBrightness = 0` sulla finestra, che su molti
  telefoni porta il pannello sotto il minimo del cursore di sistema.
- Tile nelle impostazioni rapide + azione "Disattiva" nella notifica.

## Permessi
- `SYSTEM_ALERT_WINDOW` (da concedere a mano, l'app apre la schermata giusta)
- `FOREGROUND_SERVICE` / `FOREGROUND_SERVICE_SPECIAL_USE`, `POST_NOTIFICATIONS`

## Funzioni
- Intensità 10–80% (fino al 95% con il servizio di accessibilità), filtro caldo ambra, luminosità al minimo.
- Preset Notte / Cinema / Lettura con un tocco.
- Servizio di accessibilità (facoltativo): copre anche barra di stato e notifiche e lascia passare i tocchi oltre l'80%.
- App escluse: in quelle app l'oscuramento si ferma da solo (richiede il servizio di accessibilità).
- Programmazione: accensione a un'ora fissa o al tramonto (posizione approssimativa), spegnimento all'ora scelta.
- Notifica come scheda multimediale (copertina che si riempie come il livello, barra trascinabile); un tocco apre un pannello con cursore grande che cambia la luminosità in tempo reale, preset e filtro caldo. Due tile nelle impostazioni rapide (accende e cambia livello).
- Dissolvenza in accensione e spegnimento; riparte da solo dopo il riavvio e dopo gli aggiornamenti.

## Aggiornamenti OTA
- All'avvio l'app controlla l'ultima release di `mdo-video/Dimmer` su GitHub (il repository deve essere pubblico).
  Se c'è una versione nuova compare la card "Aggiornamenti" con "Scarica e installa"; c'è anche il controllo manuale.
- A ogni push il workflow compila l'APK firmato e crea la release `v<numero esecuzione>`: quel numero è il `versionCode`.
- L'APK è firmato sempre con `app/dimmer.jks` (stessa firma a ogni build), altrimenti Android rifiuta l'aggiornamento.
  Chi aveva installato una build firmata con un'altra chiave deve disinstallarla una volta sola.

## Build
Apri la cartella in Android Studio (genera il Gradle wrapper al primo sync) e premi Run.
Requisiti: minSdk 26, compileSdk 35, AGP 8.7.3, Kotlin 2.0.21.
