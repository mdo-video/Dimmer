# Dimmer

App Android che scurisce lo schermo oltre il minimo di sistema, pensata per display AMOLED
(`com.mdovideo.dimmer`, Kotlin + Jetpack Compose, Material 3 scuro).

## Come funziona
- Un servizio in primo piano aggiunge una finestra nera a tutto schermo (`TYPE_APPLICATION_OVERLAY`),
  non toccabile: i tocchi passano all'app sotto.
- Slider di intensità 10–80%. Il tetto a 80% è voluto: da Android 12 le finestre sopra l'80% di opacità
  bloccano i tocchi verso le app sotto.
- Opzione "Luminosità al minimo": imposta anche `screenBrightness = 0` sulla finestra, che su molti
  telefoni porta il pannello sotto il minimo del cursore di sistema.
- Tile nelle impostazioni rapide + azione "Disattiva" nella notifica.

## Permessi
- `SYSTEM_ALERT_WINDOW` (da concedere a mano, l'app apre la schermata giusta)
- `FOREGROUND_SERVICE` / `FOREGROUND_SERVICE_SPECIAL_USE`, `POST_NOTIFICATIONS`

## Build
Apri la cartella in Android Studio (genera il Gradle wrapper al primo sync) e premi Run.
Requisiti: minSdk 26, compileSdk 35, AGP 8.7.3, Kotlin 2.0.21.
