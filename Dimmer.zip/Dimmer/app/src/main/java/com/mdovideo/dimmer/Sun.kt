package com.mdovideo.dimmer

import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import kotlin.math.acos
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** Ora del tramonto (equazione dell'alba/tramonto, precisione di qualche minuto). */
object Sun {
    /** Tramonto locale di [date] a [lat]/[lon] (gradi, est positivo); null se in quel giorno il sole non tramonta o non sorge. */
    fun sunset(date: LocalDate, lat: Double, lon: Double, zone: ZoneId = ZoneId.systemDefault()): LocalTime? {
        val jd = date.toEpochDay() + 2440588.0 // mezzogiorno UTC del giorno
        val n = ceil(jd - 2451545.0 + 0.0008)
        val jStar = n - lon / 360.0
        val m = (357.5291 + 0.98560028 * jStar) % 360.0
        val mr = Math.toRadians(m)
        val c = 1.9148 * sin(mr) + 0.0200 * sin(2 * mr) + 0.0003 * sin(3 * mr)
        val lambda = (m + c + 180.0 + 102.9372) % 360.0
        val lr = Math.toRadians(lambda)
        val transit = 2451545.0 + jStar + 0.0053 * sin(mr) - 0.0069 * sin(2 * lr)
        val sinDec = sin(lr) * sin(Math.toRadians(23.4397))
        val cosDec = sqrt(1 - sinDec * sinDec)
        val latR = Math.toRadians(lat)
        val cosOmega = (sin(Math.toRadians(-0.833)) - sin(latR) * sinDec) / (cos(latR) * cosDec)
        if (cosOmega < -1.0 || cosOmega > 1.0) return null
        val omega = Math.toDegrees(acos(cosOmega))
        val set = transit + omega / 360.0
        val millis = ((set - 2440587.5) * 86_400_000.0).toLong()
        return Instant.ofEpochMilli(millis).atZone(zone).toLocalTime().withSecond(0).withNano(0)
    }
}
