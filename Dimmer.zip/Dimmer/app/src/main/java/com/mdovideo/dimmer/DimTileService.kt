package com.mdovideo.dimmer

import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Tile nelle impostazioni rapide per accendere/spegnere l'oscuramento. */
class DimTileService : TileService() {

    override fun onStartListening() = refresh()

    override fun onClick() {
        if (!Settings.canDrawOverlays(this)) return
        if (Prefs.enabled(this)) DimmerService.stop(this) else DimmerService.start(this)
        refresh()
    }

    private fun refresh() {
        val tile = qsTile ?: return
        tile.state = if (Prefs.enabled(this)) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.updateTile()
    }
}
