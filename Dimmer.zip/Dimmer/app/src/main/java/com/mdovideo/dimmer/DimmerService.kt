package com.mdovideo.dimmer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.service.quicksettings.TileService
import android.view.WindowManager
import androidx.core.content.ContextCompat
import kotlin.math.roundToInt

/**
 * Servizio in primo piano: tiene l'oscuramento acceso e sceglie dove disegnarlo (finestra del servizio di
 * accessibilità, se attivo, altrimenti la sua). La notifica è una "scheda multimediale" con una barra trascinabile:
 * la posizione è l'intensità, così si regola con un solo gesto; un tocco sulla scheda apre il pannello con il cursore.
 */
class DimmerService : Service() {

    private lateinit var appLayer: OverlayLayer
    private var session: MediaSession? = null
    private val handler = Handler(Looper.getMainLooper())
    private var art: Bitmap? = null
    private var artPercent = -1
    private var notifPending = false
    private val notifRunnable = Runnable {
        notifPending = false
        publishNotification()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        appLayer = OverlayLayer(this, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        session = MediaSession(this, "Dimmer").apply {
            setCallback(object : MediaSession.Callback() {
                // Trascinando la barra della scheda: la posizione (0–100 000) è l'intensità in percentuale ×1000.
                override fun onSeekTo(pos: Long) {
                    val level = (pos / (SESSION_SCALE * 100f)).coerceIn(Prefs.MIN_LEVEL, Prefs.maxLevel(this@DimmerService))
                    Prefs.setLevel(this@DimmerService, (level * 100).roundToInt() / 100f)
                    onLevelChangedLive()
                }

                override fun onPause() = DimmerService.stop(applicationContext)
                override fun onStop() = DimmerService.stop(applicationContext)
            })
            setSessionActivity(panelIntent())
            isActive = true
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP) return shutdown(startId)

        // Chi ha usato startForegroundService deve chiamare subito startForeground, anche se poi ci si ferma.
        startForeground(NOTIF_ID, buildNotification())
        if (!Settings.canDrawOverlays(this)) return shutdown(startId)

        handler.removeCallbacksAndMessages(null)
        notifPending = false
        applyOverlay(fade = true)
        publishNotification()
        refreshTiles(this)
        return START_STICKY
    }

    /**
     * Il livello è cambiato mentre si trascina (pannello, app, barra della scheda): aggiorna subito l'overlay,
     * la notifica con calma (al massimo ogni 350 ms) per non appesantire.
     */
    fun onLevelChangedLive() {
        applyOverlay(fade = false)
        if (!notifPending) {
            notifPending = true
            handler.postDelayed(notifRunnable, 350)
        }
    }

    private fun applyOverlay(fade: Boolean) {
        val a11y = DimmerAccessibilityService.instance
        val useA11y = a11y != null && Prefs.coverSystemUi(this)
        val host: OverlayLayer? = if (useA11y) a11y?.layer else appLayer
        val other: OverlayLayer? = if (useA11y) appLayer else a11y?.layer
        other?.hide(false)
        if (host == null) return
        if (Excluded.active(this)) {
            host.hide(fade)
            return
        }
        host.show(Prefs.effectiveLevel(this), Prefs.warm(this), Prefs.minBrightness(this), fade)
    }

    /** Spegne con una dissolvenza e poi chiude il servizio (se nel frattempo è ripartito, non si ferma). */
    private fun shutdown(startId: Int): Int {
        Prefs.setEnabled(this, false)
        appLayer.hide(true)
        DimmerAccessibilityService.instance?.layer?.hide(true)
        refreshTiles(this)
        stopForeground(STOP_FOREGROUND_REMOVE)
        handler.postDelayed({ stopSelf(startId) }, OverlayLayer.FADE_MS + 60)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        appLayer.release()
        DimmerAccessibilityService.instance?.layer?.hide(false)
        session?.release()
        session = null
        if (instance === this) instance = null
        super.onDestroy()
    }

    private fun publishNotification() {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
    }

    private fun panelIntent(): PendingIntent = PendingIntent.getActivity(
        this, 0,
        Intent(this, LevelPanelActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE,
    )

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW)
        )
        val level = Prefs.effectiveLevel(this)
        val percent = (level * 100).roundToInt()
        val paused = Excluded.active(this)
        val presetName = Presets.all.firstOrNull { it.matches(level, Prefs.warm(this)) }?.name
        val subtitle = when {
            paused -> getString(R.string.notif_paused)
            presetName != null -> "$presetName · ${getString(R.string.notif_title).lowercase()}"
            else -> getString(R.string.notif_title)
        }
        if (art == null || artPercent != percent) {
            art = Art.make(level)
            artPercent = percent
        }

        val s = session
        if (s != null) {
            s.setMetadata(
                MediaMetadata.Builder()
                    .putString(MediaMetadata.METADATA_KEY_TITLE, getString(R.string.notif_level, percent))
                    .putString(MediaMetadata.METADATA_KEY_ARTIST, subtitle)
                    .putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, art)
                    .putLong(MediaMetadata.METADATA_KEY_DURATION, SESSION_SCALE.toLong() * 100)
                    .build()
            )
            // Velocità 0: la barra resta ferma sul livello, non avanza come un brano.
            s.setPlaybackState(
                PlaybackState.Builder()
                    .setActions(PlaybackState.ACTION_SEEK_TO or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_STOP)
                    .setState(PlaybackState.STATE_PLAYING, (level * 100 * SESSION_SCALE).toLong(), 0f)
                    .build()
            )
        }

        val stop = PendingIntent.getService(
            this, 1, Intent(this, DimmerService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val builder = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle(getString(R.string.notif_level, percent))
            .setContentText(subtitle)
            .setLargeIcon(art)
            .setContentIntent(panelIntent())
            .addAction(Notification.Action.Builder(null, getString(R.string.notif_stop), stop).build())
            .setOngoing(true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
        if (s != null) {
            builder.setStyle(Notification.MediaStyle().setMediaSession(s.sessionToken).setShowActionsInCompactView(0))
        }
        return builder.build()
    }

    companion object {
        const val ACTION_STOP = "com.mdovideo.dimmer.STOP"
        const val ACTION_REFRESH = "com.mdovideo.dimmer.REFRESH"
        private const val CHANNEL = "dimmer"
        private const val NOTIF_ID = 1

        /** Il servizio in esecuzione (stesso processo dell'app): serve per cambiare il livello in tempo reale. */
        @Volatile
        var instance: DimmerService? = null

        // La barra della scheda va da 0 a 100 000: ogni punto percentuale vale 1000.
        private const val SESSION_SCALE = 1000f

        /** Avvia o aggiorna l'overlay con le impostazioni correnti. */
        fun start(c: Context) {
            Prefs.setEnabled(c, true)
            runCatching { ContextCompat.startForegroundService(c, Intent(c, DimmerService::class.java)) }
        }

        /** Applica subito il livello salvato (trascinando un cursore); se il servizio non c'è, lo avvia. */
        fun live(c: Context) {
            val s = instance
            if (s != null) s.onLevelChangedLive() else start(c)
        }

        /** Rilegge le impostazioni (app in primo piano, servizio di accessibilità...) solo se l'oscuramento è acceso. */
        fun refresh(c: Context) {
            if (!Prefs.enabled(c)) return
            runCatching {
                ContextCompat.startForegroundService(c, Intent(c, DimmerService::class.java).setAction(ACTION_REFRESH))
            }
        }

        fun stop(c: Context) {
            Prefs.setEnabled(c, false)
            runCatching { c.startService(Intent(c, DimmerService::class.java).setAction(ACTION_STOP)) }
            refreshTiles(c)
        }

        fun refreshTiles(c: Context) {
            TileService.requestListeningState(c, ComponentName(c, DimTileService::class.java))
            TileService.requestListeningState(c, ComponentName(c, DimLevelTileService::class.java))
        }
    }
}
