package com.mdovideo.dimmer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.service.quicksettings.TileService
import android.view.View
import android.view.WindowManager
import androidx.core.content.ContextCompat

/** Mette un overlay nero a tutto schermo (non tocca i tocchi) e lo aggiorna in tempo reale. */
class DimmerService : Service() {

    private var wm: WindowManager? = null
    private var overlay: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP || !Settings.canDrawOverlays(this)) {
            Prefs.setEnabled(this, false)
            removeOverlay()
            TileService.requestListeningState(this, android.content.ComponentName(this, DimTileService::class.java))
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIF_ID, buildNotification())
        applyOverlay()
        return START_STICKY
    }

    private fun applyOverlay() {
        val level = Prefs.level(this)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            // L'opacità della finestra resta <= 0.8, così i tocchi passano anche su Android 12+.
            alpha = level
            screenBrightness = if (Prefs.minBrightness(this@DimmerService)) 0f
            else WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        }

        val manager = wm ?: (getSystemService(Context.WINDOW_SERVICE) as WindowManager).also { wm = it }
        val view = overlay
        if (view == null) {
            val v = View(this).apply { setBackgroundColor(Color.BLACK) }
            manager.addView(v, params)
            overlay = v
        } else {
            manager.updateViewLayout(view, params)
        }
    }

    private fun removeOverlay() {
        overlay?.let { runCatching { wm?.removeView(it) } }
        overlay = null
    }

    override fun onDestroy() {
        removeOverlay()
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, DimmerService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle(getString(R.string.notif_title))
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, getString(R.string.notif_stop), stop).build())
            .setOngoing(true)
            .build()
    }

    companion object {
        const val ACTION_STOP = "com.mdovideo.dimmer.STOP"
        private const val CHANNEL = "dimmer"
        private const val NOTIF_ID = 1

        /** Avvia o aggiorna l'overlay con le impostazioni correnti. */
        fun start(c: Context) {
            Prefs.setEnabled(c, true)
            ContextCompat.startForegroundService(c, Intent(c, DimmerService::class.java))
        }

        fun stop(c: Context) {
            Prefs.setEnabled(c, false)
            c.startService(Intent(c, DimmerService::class.java).setAction(ACTION_STOP))
        }
    }
}
