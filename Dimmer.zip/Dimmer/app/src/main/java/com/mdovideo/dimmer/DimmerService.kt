package com.mdovideo.dimmer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.service.quicksettings.TileService
import android.view.WindowManager
import androidx.core.content.ContextCompat
import kotlin.math.roundToInt

/**
 * Servizio in primo piano: tiene l'oscuramento acceso, mostra la notifica con i pulsanti −/+ e sceglie dove
 * disegnarlo (finestra del servizio di accessibilità, se attivo, altrimenti la sua).
 */
class DimmerService : Service() {

    private lateinit var appLayer: OverlayLayer
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        appLayer = OverlayLayer(this, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP) return shutdown(startId)

        // Chi ha usato startForegroundService deve chiamare subito startForeground, anche se poi ci si ferma.
        startForeground(NOTIF_ID, buildNotification())
        if (!Settings.canDrawOverlays(this)) return shutdown(startId)

        when (action) {
            ACTION_LEVEL_DOWN -> step(-STEP)
            ACTION_LEVEL_UP -> step(STEP)
        }
        handler.removeCallbacksAndMessages(null)
        applyOverlay(fade = action != ACTION_LEVEL_DOWN && action != ACTION_LEVEL_UP)
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
        refreshTiles(this)
        return START_STICKY
    }

    private fun step(delta: Float) {
        val next = (Prefs.effectiveLevel(this) + delta).coerceIn(Prefs.MIN_LEVEL, Prefs.maxLevel(this))
        Prefs.setLevel(this, (next * 100).roundToInt() / 100f)
    }

    private fun applyOverlay(fade: Boolean) {
        val a11y = DimmerAccessibilityService.instance
        val useA11y = a11y != null && Prefs.coverSystemUi(this)
        val host: OverlayLayer? = if (useA11y) a11y?.layer else appLayer
        val other: OverlayLayer? = if (useA11y) appLayer else a11y?.layer
        other?.hide(false)
        if (host == null) return
        if (Excluded.active(this)) {
            host.hide(fade)
            return
        }
        host.show(Prefs.effectiveLevel(this), Prefs.warm(this), Prefs.minBrightness(this), fade)
    }

    /** Spegne con una dissolvenza e poi chiude il servizio (se nel frattempo è ripartito, non si ferma). */
    private fun shutdown(startId: Int): Int {
        Prefs.setEnabled(this, false)
        appLayer.hide(true)
        DimmerAccessibilityService.instance?.layer?.hide(true)
        refreshTiles(this)
        stopForeground(STOP_FOREGROUND_REMOVE)
        handler.postDelayed({ stopSelf(startId) }, OverlayLayer.FADE_MS + 60)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        appLayer.release()
        DimmerAccessibilityService.instance?.layer?.hide(false)
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        fun action(code: Int, name: String) = PendingIntent.getService(
            this, code, Intent(this, DimmerService::class.java).setAction(name), PendingIntent.FLAG_IMMUTABLE
        )
        val level = (Prefs.effectiveLevel(this) * 100).roundToInt()
        val text = if (Excluded.active(this)) getString(R.string.notif_paused) else getString(R.string.notif_level, level)
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(text)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, getString(R.string.notif_down), action(2, ACTION_LEVEL_DOWN)).build())
            .addAction(Notification.Action.Builder(null, getString(R.string.notif_up), action(3, ACTION_LEVEL_UP)).build())
            .addAction(Notification.Action.Builder(null, getString(R.string.notif_stop), action(1, ACTION_STOP)).build())
            .setOngoing(true)
            .build()
    }

    companion object {
        const val ACTION_STOP = "com.mdovideo.dimmer.STOP"
        const val ACTION_LEVEL_DOWN = "com.mdovideo.dimmer.LEVEL_DOWN"
        const val ACTION_LEVEL_UP = "com.mdovideo.dimmer.LEVEL_UP"
        const val ACTION_REFRESH = "com.mdovideo.dimmer.REFRESH"
        private const val CHANNEL = "dimmer"
        private const val NOTIF_ID = 1
        private const val STEP = 0.10f

        /** Avvia o aggiorna l'overlay con le impostazioni correnti. */
        fun start(c: Context) {
            Prefs.setEnabled(c, true)
            runCatching { ContextCompat.startForegroundService(c, Intent(c, DimmerService::class.java)) }
        }

        /** Rilegge le impostazioni (app in primo piano, servizio di accessibilità...) solo se l'oscuramento è acceso. */
        fun refresh(c: Context) {
            if (!Prefs.enabled(c)) return
            runCatching {
                ContextCompat.startForegroundService(c, Intent(c, DimmerService::class.java).setAction(ACTION_REFRESH))
            }
        }

        fun stop(c: Context) {
            Prefs.setEnabled(c, false)
            runCatching { c.startService(Intent(c, DimmerService::class.java).setAction(ACTION_STOP)) }
            refreshTiles(c)
        }

        fun refreshTiles(c: Context) {
            TileService.requestListeningState(c, ComponentName(c, DimTileService::class.java))
            TileService.requestListeningState(c, ComponentName(c, DimLevelTileService::class.java))
        }
    }
}
