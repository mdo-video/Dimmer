package com.mdovideo.dimmer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.SystemClock
import android.graphics.Bitmap
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.service.quicksettings.TileService
import android.view.WindowManager
import androidx.core.content.ContextCompat
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Servizio in primo piano: tiene l'oscuramento acceso e sceglie dove disegnarlo (finestra del servizio di
 * accessibilità, se attivo, altrimenti la sua). La notifica è normale, con i pulsanti − / + e Disattiva: un tocco apre l'app.
 */
class DimmerService : Service() {

    private lateinit var appLayer: OverlayLayer
    private val handler = Handler(Looper.getMainLooper())
    private var art: Bitmap? = null
    private var artPercent = -1
    private var notifPending = false
    private var shake: SensorEventListener? = null
    private val notifRunnable = Runnable {
        notifPending = false
        publishNotification()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        appLayer = OverlayLayer(this, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP) return shutdown(startId)

        // Chi ha usato startForegroundService deve chiamare subito startForeground, anche se poi ci si ferma.
        startForeground(NOTIF_ID, buildNotification())
        if (!Settings.canDrawOverlays(this)) return shutdown(startId)

        // Pulsanti − / + della notifica e dell'isola: un passo di 5 punti percentuali.
        if (action == ACTION_UP || action == ACTION_DOWN) {
            val step = if (action == ACTION_UP) LEVEL_STEP else -LEVEL_STEP
            val next = (Prefs.level(this) + step).coerceIn(Prefs.MIN_LEVEL, Prefs.maxLevel(this))
            Prefs.setLevel(this, (next * 100).roundToInt() / 100f)
        }

        handler.removeCallbacksAndMessages(null)
        notifPending = false
        applyOverlay(fade = true)
        publishNotification()
        refreshTiles(this)
        return START_STICKY
    }

    /**
     * Il livello è cambiato mentre si trascina (pannello, app, barra della scheda): aggiorna subito l'overlay,
     * la notifica con calma (al massimo ogni 350 ms) per non appesantire.
     */
    fun onLevelChangedLive() {
        applyOverlay(fade = false)
        if (!notifPending) {
            notifPending = true
            handler.postDelayed(notifRunnable, 350)
        }
    }

    private fun applyOverlay(fade: Boolean) {
        val a11y = DimmerAccessibilityService.instance
        val useA11y = a11y != null && Prefs.coverSystemUi(this)
        val host: OverlayLayer? = if (useA11y) a11y?.layer else appLayer
        val other: OverlayLayer? = if (useA11y) appLayer else a11y?.layer
        other?.hide(false)
        if (host == null) return
        if (Excluded.active(this)) {
            host.hide(fade)
            return
        }
        host.show(Prefs.effectiveLevel(this), Prefs.warm(this), Prefs.minBrightness(this), fade)
        host.setPanic(Prefs.panicButton(this)) { stop(applicationContext) }
        updateShake()
    }

    /** Scuotere forte il telefono (4 scossoni in poco più di un secondo) spegne l'oscuramento. */
    private fun updateShake() {
        val sm = getSystemService(SensorManager::class.java)
        val want = Prefs.panicShake(this)
        if (want && shake == null) {
            val sensor = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
            val l = object : SensorEventListener {
                private var count = 0
                private var first = 0L
                private var last = 0L
                override fun onSensorChanged(e: SensorEvent) {
                    val g = sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]) /
                        SensorManager.GRAVITY_EARTH
                    if (g < 2.6f) return
                    val now = SystemClock.elapsedRealtime()
                    if (now - last < 120) return
                    last = now
                    if (now - first > 1200) { first = now; count = 0 }
                    if (++count >= 4) { count = 0; stop(applicationContext) }
                }
                override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
            }
            sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_GAME)
            shake = l
        } else if (!want) {
            stopShake()
        }
    }

    private fun stopShake() {
        shake?.let { getSystemService(SensorManager::class.java).unregisterListener(it) }
        shake = null
    }

    /** Spegne con una dissolvenza e poi chiude il servizio (se nel frattempo è ripartito, non si ferma). */
    private fun shutdown(startId: Int): Int {
        Prefs.setEnabled(this, false)
        stopShake()
        appLayer.hide(true)
        DimmerAccessibilityService.instance?.layer?.hide(true)
        refreshTiles(this)
        stopForeground(STOP_FOREGROUND_REMOVE)
        handler.postDelayed({ stopSelf(startId) }, OverlayLayer.FADE_MS + 60)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        stopShake()
        handler.removeCallbacksAndMessages(null)
        appLayer.release()
        DimmerAccessibilityService.instance?.layer?.hide(false)
        if (instance === this) instance = null
        super.onDestroy()
    }

    private fun publishNotification() {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
    }

    private fun panelIntent(): PendingIntent = PendingIntent.getActivity(
        this, 0,
        Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE,
    )

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW)
        )
        val level = Prefs.effectiveLevel(this)
        val percent = (level * 100).roundToInt()
        val paused = Excluded.active(this)
        val presetName = Presets.all.firstOrNull { it.matches(level, Prefs.warm(this)) }?.name
        val subtitle = when {
            paused -> getString(R.string.notif_paused)
            presetName != null -> "$presetName · ${getString(R.string.notif_title).lowercase()}"
            else -> getString(R.string.notif_title)
        }
        if (art == null || artPercent != percent) {
            art = Art.make(level)
            artPercent = percent
        }

        val stop = PendingIntent.getService(
            this, 1, Intent(this, DimmerService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val down = PendingIntent.getService(
            this, 2, Intent(this, DimmerService::class.java).setAction(ACTION_DOWN), PendingIntent.FLAG_IMMUTABLE
        )
        val up = PendingIntent.getService(
            this, 3, Intent(this, DimmerService::class.java).setAction(ACTION_UP), PendingIntent.FLAG_IMMUTABLE
        )
        val actDown = Notification.Action.Builder(null, "−  Meno", down).build()
        val actUp = Notification.Action.Builder(null, "+  Più", up).build()
        val actStop = Notification.Action.Builder(null, getString(R.string.notif_stop), stop).build()
        val builder = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle(getString(R.string.notif_level, percent))
            .setContentText(subtitle)
            .setLargeIcon(art)
            .setContentIntent(panelIntent())
            .setColor(0xFFFFB870.toInt())
            .addAction(actDown)
            .addAction(actUp)
            .addAction(actStop)
            .setOngoing(true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
        return builder.build()
    }

    companion object {
        const val ACTION_STOP = "com.mdovideo.dimmer.STOP"
        const val ACTION_REFRESH = "com.mdovideo.dimmer.REFRESH"
        const val ACTION_UP = "com.mdovideo.dimmer.UP"
        const val ACTION_DOWN = "com.mdovideo.dimmer.DOWN"
        private const val LEVEL_STEP = 0.05f
        private const val CHANNEL = "dimmer"
        private const val NOTIF_ID = 1

        /** Il servizio in esecuzione (stesso processo dell'app): serve per cambiare il livello in tempo reale. */
        @Volatile
        var instance: DimmerService? = null

        /** Avvia o aggiorna l'overlay con le impostazioni correnti. */
        fun start(c: Context) {
            Prefs.setEnabled(c, true)
            runCatching { ContextCompat.startForegroundService(c, Intent(c, DimmerService::class.java)) }
        }

        /** Applica subito il livello salvato (trascinando un cursore); se il servizio non c'è, lo avvia. */
        fun live(c: Context) {
            val s = instance
            if (s != null) s.onLevelChangedLive() else start(c)
        }

        /** Rilegge le impostazioni (app in primo piano, servizio di accessibilità...) solo se l'oscuramento è acceso. */
        fun refresh(c: Context) {
            if (!Prefs.enabled(c)) return
            runCatching {
                ContextCompat.startForegroundService(c, Intent(c, DimmerService::class.java).setAction(ACTION_REFRESH))
            }
        }

        fun stop(c: Context) {
            Prefs.setEnabled(c, false)
            runCatching { c.startService(Intent(c, DimmerService::class.java).setAction(ACTION_STOP)) }
            refreshTiles(c)
        }

        fun refreshTiles(c: Context) {
            TileService.requestListeningState(c, ComponentName(c, DimTileService::class.java))
            TileService.requestListeningState(c, ComponentName(c, DimLevelTileService::class.java))
        }
    }
}
