package com.mdovideo.dimmer

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

/**
 * Serve a due cose, e solo a queste: ospita la finestra dell'oscuramento (TYPE_ACCESSIBILITY_OVERLAY, che sta sopra
 * barra di stato e notifiche e lascia passare i tocchi anche oltre l'80%) e sa quale app è in primo piano,
 * per fermare l'oscuramento nelle app escluse. Non legge il contenuto dello schermo.
 */
class DimmerAccessibilityService : AccessibilityService() {

    var layer: OverlayLayer? = null
        private set

    override fun onServiceConnected() {
        super.onServiceConnected()
        layer = OverlayLayer(this, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
        instance = this
        DimmerService.refresh(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == "com.android.systemui" || pkg == imePackage()) return
        // Le finestre dell'oscuramento sono di Dimmer: contano solo gli eventi della sua schermata principale.
        if (pkg == packageName && event.className?.toString()?.endsWith("MainActivity") != true) return
        if (pkg == Foreground.pkg) return
        Foreground.pkg = pkg
        if (Prefs.enabled(this) && Prefs.excluded(this).isNotEmpty()) DimmerService.refresh(this)
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun cleanup() {
        layer?.release()
        layer = null
        if (instance === this) {
            instance = null
            // L'oscuramento torna alla finestra normale del servizio principale.
            DimmerService.refresh(this)
        }
    }

    private fun imePackage(): String? =
        Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
            ?.let { ComponentName.unflattenFromString(it)?.packageName }

    companion object {
        @Volatile
        var instance: DimmerAccessibilityService? = null

        /** Vero se il servizio è acceso nelle impostazioni di accessibilità. */
        fun isEnabled(c: Context): Boolean {
            val me = ComponentName(c, DimmerAccessibilityService::class.java)
            val list = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
                ?: return false
            return list.split(':').any { ComponentName.unflattenFromString(it) == me }
        }
    }
}
