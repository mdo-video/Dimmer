package com.mdovideo.dimmer

import android.content.Context

/** Impostazioni salvate: stato on/off, livello di oscuramento, luminosità finestra al minimo. */
object Prefs {
    const val MIN_LEVEL = 0.10f
    const val MAX_LEVEL = 0.80f // oltre 0.8 Android 12+ blocca i tocchi attraverso l'overlay

    private fun sp(c: Context) = c.getSharedPreferences("dimmer", Context.MODE_PRIVATE)

    fun enabled(c: Context) = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    fun level(c: Context) = sp(c).getFloat("level", 0.6f).coerceIn(MIN_LEVEL, MAX_LEVEL)
    fun setLevel(c: Context, v: Float) = sp(c).edit().putFloat("level", v).apply()

    fun minBrightness(c: Context) = sp(c).getBoolean("min_brightness", true)
    fun setMinBrightness(c: Context, v: Boolean) = sp(c).edit().putBoolean("min_brightness", v).apply()
}
