package com.mdovideo.dimmer

import android.content.Context

/** Impostazioni salvate: stato, livello, filtro caldo, programmazione, app escluse. */
object Prefs {
    const val MIN_LEVEL = 0.10f
    const val MAX_LEVEL = 0.80f // oltre 0.8 Android 12+ blocca i tocchi attraverso un overlay "normale"
    const val MAX_LEVEL_TRUSTED = 0.95f // l'overlay del servizio di accessibilità è "fidato": i tocchi passano comunque

    private fun sp(c: Context) = c.getSharedPreferences("dimmer", Context.MODE_PRIVATE)

    fun enabled(c: Context) = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    fun level(c: Context) = sp(c).getFloat("level", 0.6f).coerceIn(MIN_LEVEL, MAX_LEVEL_TRUSTED)
    fun setLevel(c: Context, v: Float) = sp(c).edit().putFloat("level", v).apply()

    fun minBrightness(c: Context) = sp(c).getBoolean("min_brightness", true)
    fun setMinBrightness(c: Context, v: Boolean) = sp(c).edit().putBoolean("min_brightness", v).apply()

    /** Filtro caldo (tinta ambra) da 0 a 1. */
    fun warm(c: Context) = sp(c).getFloat("warm", 0f).coerceIn(0f, 1f)
    fun setWarm(c: Context, v: Float) = sp(c).edit().putFloat("warm", v).apply()

    /** Se il servizio di accessibilità è attivo, usa la sua finestra: copre anche barra di stato e notifiche. */
    fun coverSystemUi(c: Context) = sp(c).getBoolean("cover_system_ui", true)
    fun setCoverSystemUi(c: Context, v: Boolean) = sp(c).edit().putBoolean("cover_system_ui", v).apply()

    /** Vero se l'oscuramento passa dalla finestra del servizio di accessibilità (livelli fino al 95%). */
    fun trusted(c: Context) = coverSystemUi(c) && DimmerAccessibilityService.instance != null
    fun maxLevel(c: Context) = if (trusted(c)) MAX_LEVEL_TRUSTED else MAX_LEVEL
    fun effectiveLevel(c: Context) = level(c).coerceAtMost(maxLevel(c))

    // Programmazione
    fun scheduleEnabled(c: Context) = sp(c).getBoolean("sched_on", false)
    fun setScheduleEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("sched_on", v).apply()
    fun scheduleStart(c: Context) = sp(c).getInt("sched_start", 22 * 60)
    fun setScheduleStart(c: Context, minutes: Int) = sp(c).edit().putInt("sched_start", minutes).apply()
    fun scheduleEnd(c: Context) = sp(c).getInt("sched_end", 7 * 60)
    fun setScheduleEnd(c: Context, minutes: Int) = sp(c).edit().putInt("sched_end", minutes).apply()
    fun scheduleSunset(c: Context) = sp(c).getBoolean("sched_sunset", false)
    fun setScheduleSunset(c: Context, v: Boolean) = sp(c).edit().putBoolean("sched_sunset", v).apply()

    fun hasLocation(c: Context) = sp(c).contains("lat") && sp(c).contains("lon")
    fun lat(c: Context) = sp(c).getFloat("lat", 0f).toDouble()
    fun lon(c: Context) = sp(c).getFloat("lon", 0f).toDouble()
    fun setLocation(c: Context, lat: Double, lon: Double) =
        sp(c).edit().putFloat("lat", lat.toFloat()).putFloat("lon", lon.toFloat()).apply()

    // App in cui l'oscuramento si ferma
    fun excluded(c: Context): Set<String> = sp(c).getStringSet("excluded", emptySet())?.toSet() ?: emptySet()
    fun setExcluded(c: Context, v: Set<String>) = sp(c).edit().putStringSet("excluded", HashSet(v)).apply()
}
