package com.mdovideo.dimmer

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.ui.graphics.vector.ImageVector
import kotlin.math.abs

/** Un'impostazione pronta: intensità, filtro caldo e luminosità al minimo. */
data class Preset(
    val name: String,
    val icon: ImageVector,
    val level: Float,
    val warm: Float,
    val minBrightness: Boolean,
) {
    fun matches(level: Float, warm: Float) = abs(this.level - level) < 0.03f && abs(this.warm - warm) < 0.03f
}

object Presets {
    val all = listOf(
        Preset("Notte", Icons.Filled.NightsStay, 0.70f, 0.30f, true),
        Preset("Cinema", Icons.Filled.Movie, 0.80f, 0f, true),
        Preset("Lettura", Icons.Filled.Book, 0.40f, 0.45f, false),
    )
}
