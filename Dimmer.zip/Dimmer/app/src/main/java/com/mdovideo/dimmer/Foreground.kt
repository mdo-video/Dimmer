package com.mdovideo.dimmer

import android.content.Context

/** L'app in primo piano, come la vede il servizio di accessibilità. */
object Foreground {
    @Volatile
    var pkg: String = ""
}

/** Vero se l'app in primo piano è tra quelle in cui l'oscuramento deve fermarsi. */
object Excluded {
    fun active(c: Context): Boolean = Foreground.pkg.isNotEmpty() && Foreground.pkg in Prefs.excluded(c)
}
