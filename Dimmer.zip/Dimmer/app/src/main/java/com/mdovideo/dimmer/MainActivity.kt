package com.mdovideo.dimmer

import android.Manifest
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LargeTopAppBar
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.core.content.pm.PackageInfoCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            DimmerTheme {
                DimmerScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DimmerScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme

    // "tick" cambia quando si torna nell'app (da impostazioni di sistema, accessibilità...): rilegge tutto.
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    val hasOverlay = remember(tick) { Settings.canDrawOverlays(ctx) }
    val a11yOn = remember(tick) { DimmerAccessibilityService.isEnabled(ctx) }
    val maxLevel = remember(tick) { Prefs.maxLevel(ctx) }
    val trusted = remember(tick) { Prefs.trusted(ctx) }
    var enabled by remember(tick) { mutableStateOf(Prefs.enabled(ctx)) }
    var level by remember(tick) { mutableStateOf(Prefs.effectiveLevel(ctx)) }
    var warm by remember(tick) { mutableStateOf(Prefs.warm(ctx)) }
    var minBrightness by remember(tick) { mutableStateOf(Prefs.minBrightness(ctx)) }
    var showApps by remember { mutableStateOf(false) }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}

    fun apply() { if (enabled) DimmerService.live(ctx) }

    fun ensureOn() {
        if (!enabled) {
            enabled = true
            if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        DimmerService.start(ctx)
    }

    fun toggle(on: Boolean) {
        if (on) ensureOn() else { enabled = false; DimmerService.stop(ctx) }
    }

    fun pick(p: Preset) {
        level = p.level.coerceAtMost(maxLevel)
        warm = p.warm
        minBrightness = p.minBrightness
        Prefs.setLevel(ctx, level)
        Prefs.setWarm(ctx, warm)
        Prefs.setMinBrightness(ctx, minBrightness)
        ensureOn()
    }

    // Aggiornamenti OTA
    val pkg = remember { runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0) }.getOrNull() }
    val currentCode = remember { pkg?.let { PackageInfoCompat.getLongVersionCode(it).toInt() } ?: 0 }
    val currentName = remember { pkg?.versionName ?: "" }
    var update by remember { mutableStateOf<Updater.Info?>(null) }
    var checking by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf<Float?>(null) }
    var message by remember { mutableStateOf<String?>(null) }

    fun check(silent: Boolean) {
        scope.launch {
            checking = true
            if (!silent) message = null
            val r = Updater.latest()
            checking = false
            r.onSuccess { info ->
                if (info.versionCode > currentCode) {
                    update = info
                } else {
                    update = null
                    if (!silent) message = "Hai già l'ultima versione."
                }
            }.onFailure { if (!silent) message = it.message ?: "Controllo non riuscito." }
        }
    }

    fun install(info: Updater.Info) {
        scope.launch {
            message = null
            progress = 0f
            val r = Updater.download(ctx, info) { progress = it }
            progress = null
            r.onSuccess { apk ->
                if (Updater.install(ctx, apk) == Updater.InstallResult.NEEDS_PERMISSION) {
                    message = "Concedi il permesso di installare app, poi riprova."
                }
            }.onFailure { message = it.message ?: "Download non riuscito." }
        }
    }

    LaunchedEffect(Unit) {
        check(true)
        Schedule.sync(ctx)
    }

    val scroll = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()

    Scaffold(
        modifier = Modifier.nestedScroll(scroll.nestedScrollConnection),
        containerColor = cs.background,
        topBar = {
            LargeTopAppBar(
                title = { Text("Dimmer") },
                scrollBehavior = scroll,
                colors = TopAppBarDefaults.largeTopAppBarColors(
                    containerColor = cs.background,
                    scrolledContainerColor = cs.surfaceContainer,
                ),
            )
        },
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                "Scurisce lo schermo oltre il minimo di sistema. Sull'AMOLED i pixel neri sono spenti.",
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 8.dp),
            )

            if (!hasOverlay) {
                PermissionCard()
            } else {
                MainToggleCard(enabled = enabled, onToggle = { toggle(it) })
                PresetsRow(level = level, warm = warm, onPick = { pick(it) })
                LevelCard(
                    level = level,
                    maxLevel = maxLevel,
                    trusted = trusted,
                    onChange = { level = it; Prefs.setLevel(ctx, it); apply() },
                )
                WarmCard(warm = warm, onChange = { warm = it; Prefs.setWarm(ctx, it); apply() })
                SwitchCard(
                    title = "Luminosità al minimo",
                    subtitle = "Chiede anche al pannello la luminosità più bassa (dipende dal telefono).",
                    checked = minBrightness,
                    onChecked = { minBrightness = it; Prefs.setMinBrightness(ctx, it); apply() },
                )
                Text(
                    "Nella notifica trascini la barra per cambiare l'intensità; toccandola si apre un pannello col cursore. Nelle impostazioni rapide trovi due tile: uno accende, l'altro cambia livello.",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 8.dp),
                )
            }

            AccessibilityCard(tick = tick, onChanged = { tick++ })
            ScheduleCard(tick = tick, onChanged = { tick++ })
            ExclusionsCard(tick = tick, a11yOn = a11yOn, onOpen = { showApps = true })
            UpdateCard(
                info = update,
                currentName = currentName,
                checking = checking,
                progress = progress,
                message = message,
                onCheck = { check(false) },
                onInstall = { install(it) },
            )
            Spacer(Modifier.size(8.dp))
        }
    }

    if (showApps) AppPickerSheet(onDismiss = { showApps = false }, onChanged = { tick++ })
}
