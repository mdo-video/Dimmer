package com.mdovideo.dimmer

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.runtime.DisposableEffect

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = Color.Black,
                    surface = Color(0xFF121212),
                    surfaceVariant = Color(0xFF1A1A1A)
                )
            ) {
                DimmerScreen()
            }
        }
    }
}

@Composable
private fun DimmerScreen() {
    val ctx = LocalContext.current
    var hasOverlay by remember { mutableStateOf(Settings.canDrawOverlays(ctx)) }
    var enabled by remember { mutableStateOf(Prefs.enabled(ctx)) }
    var level by remember { mutableStateOf(Prefs.level(ctx)) }
    var minBrightness by remember { mutableStateOf(Prefs.minBrightness(ctx)) }

    // Ricontrolla il permesso quando si torna dalla schermata di sistema.
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) {
                hasOverlay = Settings.canDrawOverlays(ctx)
                enabled = Prefs.enabled(ctx)
            }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}

    fun apply() { if (enabled) DimmerService.start(ctx) }

    Column(
        Modifier.fillMaxSize().background(Color.Black).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Spacer(Modifier.height(24.dp))
        Text("Dimmer", style = MaterialTheme.typography.headlineLarge)
        Text(
            "Scurisce lo schermo oltre il minimo di sistema. Sull'AMOLED i pixel neri sono spenti.",
            style = MaterialTheme.typography.bodyMedium,
            color = Color(0xFFAAAAAA)
        )

        if (!hasOverlay) {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A)), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Serve il permesso \"Mostra sopra altre app\".")
                    Button(onClick = {
                        ctx.startActivity(
                            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                        )
                    }) { Text("Apri impostazioni") }
                }
            }
        } else {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A)), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Oscuramento attivo", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                        Switch(checked = enabled, onCheckedChange = {
                            enabled = it
                            if (it) {
                                if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                DimmerService.start(ctx)
                            } else DimmerService.stop(ctx)
                        })
                    }
                    Text("Intensità: ${(level * 100).toInt()}%", color = Color(0xFFAAAAAA))
                    Slider(
                        value = level,
                        onValueChange = { level = it; Prefs.setLevel(ctx, it); apply() },
                        valueRange = Prefs.MIN_LEVEL..Prefs.MAX_LEVEL
                    )
                }
            }
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A)), shape = RoundedCornerShape(20.dp)) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Luminosità al minimo", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Chiede anche al pannello la luminosità più bassa (dipende dal telefono).",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFAAAAAA)
                        )
                    }
                    Switch(checked = minBrightness, onCheckedChange = {
                        minBrightness = it; Prefs.setMinBrightness(ctx, it); apply()
                    })
                }
            }
            Text(
                "Puoi anche accenderlo dal tile nelle impostazioni rapide.",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF777777)
            )
        }
    }
}
