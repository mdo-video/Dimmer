package com.mdovideo.dimmer

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrightnessLow
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LargeTopAppBar
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.core.content.pm.PackageInfoCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            DimmerTheme {
                DimmerScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DimmerScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme

    var hasOverlay by remember { mutableStateOf(Settings.canDrawOverlays(ctx)) }
    var enabled by remember { mutableStateOf(Prefs.enabled(ctx)) }
    var level by remember { mutableStateOf(Prefs.level(ctx)) }
    var minBrightness by remember { mutableStateOf(Prefs.minBrightness(ctx)) }

    // Ricontrolla il permesso quando si torna dalla schermata di sistema.
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) {
                hasOverlay = Settings.canDrawOverlays(ctx)
                enabled = Prefs.enabled(ctx)
            }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}

    fun apply() { if (enabled) DimmerService.start(ctx) }

    fun toggle(on: Boolean) {
        enabled = on
        if (on) {
            if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            DimmerService.start(ctx)
        } else DimmerService.stop(ctx)
    }

    // Aggiornamenti OTA
    val pkg = remember { runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0) }.getOrNull() }
    val currentCode = remember { pkg?.let { PackageInfoCompat.getLongVersionCode(it).toInt() } ?: 0 }
    val currentName = remember { pkg?.versionName ?: "" }
    var update by remember { mutableStateOf<Updater.Info?>(null) }
    var checking by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf<Float?>(null) }
    var message by remember { mutableStateOf<String?>(null) }

    fun check(silent: Boolean) {
        scope.launch {
            checking = true
            if (!silent) message = null
            val r = Updater.latest()
            checking = false
            r.onSuccess { info ->
                if (info.versionCode > currentCode) {
                    update = info
                } else {
                    update = null
                    if (!silent) message = "Hai già l'ultima versione."
                }
            }.onFailure { if (!silent) message = it.message ?: "Controllo non riuscito." }
        }
    }

    fun install(info: Updater.Info) {
        scope.launch {
            message = null
            progress = 0f
            val r = Updater.download(ctx, info) { progress = it }
            progress = null
            r.onSuccess { apk ->
                if (Updater.install(ctx, apk) == Updater.InstallResult.NEEDS_PERMISSION) {
                    message = "Concedi il permesso di installare app, poi riprova."
                }
            }.onFailure { message = it.message ?: "Download non riuscito." }
        }
    }

    LaunchedEffect(Unit) { check(true) }

    val scroll = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()
    val cardShape = RoundedCornerShape(28.dp)

    Scaffold(
        modifier = Modifier.nestedScroll(scroll.nestedScrollConnection),
        containerColor = cs.background,
        topBar = {
            LargeTopAppBar(
                title = { Text("Dimmer") },
                scrollBehavior = scroll,
                colors = TopAppBarDefaults.largeTopAppBarColors(
                    containerColor = cs.background,
                    scrolledContainerColor = cs.surfaceContainer,
                ),
            )
        },
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                "Scurisce lo schermo oltre il minimo di sistema. Sull'AMOLED i pixel neri sono spenti.",
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 8.dp),
            )

            if (!hasOverlay) {
                Card(
                    shape = cardShape,
                    colors = CardDefaults.cardColors(containerColor = cs.tertiaryContainer, contentColor = cs.onTertiaryContainer),
                ) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Warning, null)
                            Spacer(Modifier.width(12.dp))
                            Text("Serve un permesso", style = MaterialTheme.typography.titleMedium)
                        }
                        Text("Per oscurare lo schermo serve \"Mostra sopra altre app\".", style = MaterialTheme.typography.bodyMedium)
                        Button(onClick = {
                            ctx.startActivity(
                                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                            )
                        }) { Text("Apri impostazioni") }
                    }
                }
            } else {
                // Interruttore principale
                Card(
                    shape = cardShape,
                    colors = CardDefaults.cardColors(
                        containerColor = if (enabled) cs.primaryContainer else cs.surfaceContainerHigh,
                        contentColor = if (enabled) cs.onPrimaryContainer else cs.onSurface,
                    ),
                    modifier = Modifier.clip(cardShape).clickable { toggle(!enabled) },
                ) {
                    Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = if (enabled) cs.primary else cs.surfaceContainerHighest,
                            contentColor = if (enabled) cs.onPrimary else cs.onSurfaceVariant,
                        ) {
                            Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) {
                                Icon(Icons.Filled.NightsStay, null)
                            }
                        }
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Oscuramento", style = MaterialTheme.typography.titleLarge)
                            Text(if (enabled) "Attivo" else "Spento", style = MaterialTheme.typography.bodyMedium)
                        }
                        Switch(
                            checked = enabled,
                            onCheckedChange = null,
                            thumbContent = if (enabled) ({ Icon(Icons.Filled.Check, null, Modifier.size(16.dp)) }) else null,
                        )
                    }
                }

                // Intensità
                Card(
                    shape = cardShape,
                    colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh),
                ) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.BrightnessLow, null, tint = cs.primary)
                            Spacer(Modifier.width(12.dp))
                            Text("Intensità", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                            Text("${(level * 100).toInt()}%", style = MaterialTheme.typography.headlineMedium, color = cs.primary)
                        }
                        Slider(
                            value = level,
                            onValueChange = { level = it; Prefs.setLevel(ctx, it); apply() },
                            valueRange = Prefs.MIN_LEVEL..Prefs.MAX_LEVEL,
                        )
                        Text(
                            "Massimo 80%: oltre, Android 12+ non fa più passare i tocchi alle app sotto.",
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant,
                        )
                    }
                }

                // Luminosità al minimo
                Card(
                    shape = cardShape,
                    colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerHigh),
                    modifier = Modifier.clip(cardShape).clickable {
                        minBrightness = !minBrightness; Prefs.setMinBrightness(ctx, minBrightness); apply()
                    },
                ) {
                    Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Luminosità al minimo", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "Chiede anche al pannello la luminosità più bassa (dipende dal telefono).",
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant,
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Switch(
                            checked = minBrightness,
                            onCheckedChange = null,
                            thumbContent = if (minBrightness) ({ Icon(Icons.Filled.Check, null, Modifier.size(16.dp)) }) else null,
                        )
                    }
                }

                Text(
                    "Puoi anche accenderlo dal tile nelle impostazioni rapide.",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 8.dp),
                )
            }

            // Aggiornamenti
            val info = update
            Card(
                shape = cardShape,
                colors = CardDefaults.cardColors(
                    containerColor = if (info != null) cs.secondaryContainer else cs.surfaceContainerHigh,
                    contentColor = if (info != null) cs.onSecondaryContainer else cs.onSurface,
                ),
            ) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.SystemUpdate, null, tint = if (info != null) cs.onSecondaryContainer else cs.primary)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Aggiornamenti", style = MaterialTheme.typography.titleMedium)
                            Text(
                                if (info != null) "Nuova versione disponibile (${info.tag})" else "Versione $currentName",
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                    }
                    val p = progress
                    if (p != null) {
                        LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth())
                        Text("Scarico l'aggiornamento… ${(p * 100).toInt()}%", style = MaterialTheme.typography.bodySmall)
                    } else if (info != null) {
                        Button(onClick = { install(info) }) { Text("Scarica e installa") }
                    } else {
                        OutlinedButton(onClick = { check(false) }, enabled = !checking) {
                            if (checking) {
                                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.width(8.dp))
                            }
                            Text("Controlla aggiornamenti")
                        }
                    }
                    message?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                }
            }
            Spacer(Modifier.size(8.dp))
        }
    }
}
