package com.mdovideo.dimmer

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import kotlin.math.roundToInt

/** Copertina della notifica: un riquadro che si riempie dal basso come il livello, con la percentuale al centro. */
object Art {
    private const val SIZE = 320

    fun make(level: Float): Bitmap {
        val s = SIZE.toFloat()
        val bmp = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val clip = Path().apply { addRoundRect(RectF(0f, 0f, s, s), 72f, 72f, Path.Direction.CW) }
        canvas.clipPath(clip)
        canvas.drawColor(0xFF2A221D.toInt())

        val top = s * (1f - level.coerceIn(0f, 1f))
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, top, 0f, s, 0xFFFFB454.toInt(), 0xFFC8691A.toInt(), Shader.TileMode.CLAMP)
        }
        canvas.drawRect(0f, top, s, s, fill)

        val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 128f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            setShadowLayer(10f, 0f, 3f, 0x99000000.toInt())
        }
        val y = s / 2f - (text.descent() + text.ascent()) / 2f
        canvas.drawText((level * 100).roundToInt().toString(), s / 2f, y, text)
        return bmp
    }

    /** Icona tonda per i pulsanti dell'isola: simbolo bianco su sfondo ambra. */
    fun button(symbol: String): Bitmap {
        val size = 192
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val half = size / 2f
        canvas.drawCircle(half, half, half, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFE08A2E.toInt() })
        val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 120f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(symbol, half, half - (text.descent() + text.ascent()) / 2f, text)
        return bmp
    }
}
