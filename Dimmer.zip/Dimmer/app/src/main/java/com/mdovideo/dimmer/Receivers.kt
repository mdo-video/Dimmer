package com.mdovideo.dimmer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Scatta all'ora di accensione o spegnimento della programmazione. */
class ScheduleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Schedule.ACTION) return
        Schedule.onAlarm(context, intent.getBooleanExtra(Schedule.EXTRA_ON, false))
    }
}

/** Dopo il riavvio del telefono o un aggiornamento dell'app rimette tutto a posto. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED && intent.action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        Schedule.refreshLocation(context)
        if (Prefs.scheduleEnabled(context)) Schedule.arm(context)
        val shouldBeOn = Prefs.enabled(context) || (Prefs.scheduleEnabled(context) && Schedule.inWindow(context))
        if (shouldBeOn) DimmerService.start(context)
    }
}
