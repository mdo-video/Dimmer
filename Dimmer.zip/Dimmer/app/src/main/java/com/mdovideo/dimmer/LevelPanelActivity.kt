package com.mdovideo.dimmer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrightnessLow
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

// Il pannello è sempre scuro: si usa soprattutto di sera.
private val Amber = Color(0xFFFFB454)
private val OnAmber = Color(0xFF2A1A00)
private val Sheet = Color(0xFF16171B)
private val Track = Color(0xFF24262C)
private val Muted = Color(0xFFA4A6AF)
private val Light = Color(0xFFF2F2F3)
private val Outline = Color(0xFF3B3D45)

/**
 * Pannello che si apre sopra l'app in uso toccando la notifica: cursore grande che cambia la luminosità
 * in tempo reale mentre trascini, preset, filtro caldo e Spegni. Un tocco fuori lo chiude.
 */
class LevelPanelActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            DimmerTheme {
                PanelContent(onClose = { finish() }, onOpenApp = {
                    startActivity(android.content.Intent(this, MainActivity::class.java))
                    finish()
                })
            }
        }
    }
}

@Composable
private fun PanelContent(onClose: () -> Unit, onOpenApp: () -> Unit) {
    val ctx = LocalContext.current
    val maxLevel = remember { Prefs.maxLevel(ctx) }
    var level by remember { mutableFloatStateOf(Prefs.effectiveLevel(ctx)) }
    var warm by remember { mutableFloatStateOf(Prefs.warm(ctx)) }

    fun setLevel(v: Float) {
        level = v
        Prefs.setLevel(ctx, v)
        DimmerService.live(ctx)
    }

    fun setWarm(v: Float) {
        warm = v
        Prefs.setWarm(ctx, v)
        DimmerService.live(ctx)
    }

    fun pick(p: Preset) {
        level = p.level.coerceAtMost(maxLevel)
        warm = p.warm
        Prefs.setLevel(ctx, level)
        Prefs.setWarm(ctx, warm)
        Prefs.setMinBrightness(ctx, p.minBrightness)
        DimmerService.live(ctx)
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0x8C000000))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClose),
        contentAlignment = Alignment.BottomCenter,
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp))
                .background(Sheet)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
                .navigationBarsPadding()
                .padding(start = 24.dp, end = 24.dp, top = 12.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(22.dp),
        ) {
            Box(
                Modifier.align(Alignment.CenterHorizontally).size(40.dp, 4.dp)
                    .clip(RoundedCornerShape(2.dp)).background(Outline)
            )
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Intensità", color = Muted, fontSize = 17.sp)
                Text(
                    "${(level * 100).roundToInt()}%",
                    color = Amber, fontSize = 56.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-2).sp,
                )
            }
            PillSlider(value = level, min = Prefs.MIN_LEVEL, max = maxLevel, onChange = { setLevel(it) })

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Presets.all.forEach { p ->
                    val selected = p.matches(level, warm)
                    val shape = RoundedCornerShape(22.dp)
                    Column(
                        Modifier
                            .weight(1f)
                            .height(84.dp)
                            .clip(shape)
                            .background(if (selected) Color(0xFF2B2217) else Track)
                            .border(1.5.dp, if (selected) Amber else Color.Transparent, shape)
                            .clickable { pick(p) },
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                        Icon(p.icon, null, Modifier.size(24.dp), tint = if (selected) Amber else Light)
                        Spacer(Modifier.height(8.dp))
                        Text(p.name, color = if (selected) Amber else Light, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Filtro caldo", Modifier.width(96.dp), color = Muted, fontSize = 15.sp)
                Slider(
                    value = warm,
                    onValueChange = { setWarm(it) },
                    modifier = Modifier.weight(1f),
                    colors = SliderDefaults.colors(thumbColor = Amber, activeTrackColor = Amber, inactiveTrackColor = Track),
                )
                Text("${(warm * 100).roundToInt()}%", Modifier.width(44.dp), color = Light, fontSize = 15.sp, textAlign = TextAlign.End)
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(
                    onClick = { DimmerService.stop(ctx); onClose() },
                    modifier = Modifier.weight(1f).height(52.dp),
                    shape = RoundedCornerShape(26.dp),
                    border = BorderStroke(1.5.dp, Outline),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Light),
                ) { Text("Spegni", fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
                Button(
                    onClick = onOpenApp,
                    modifier = Modifier.weight(1f).height(52.dp),
                    shape = RoundedCornerShape(26.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Track, contentColor = Light),
                ) { Text("Apri Dimmer", fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
            }
        }
    }
}

/** Barra grande a pillola: il riempimento è l'intensità (0–100%), si tocca o si trascina e risponde subito. */
@Composable
private fun PillSlider(value: Float, min: Float, max: Float, onChange: (Float) -> Unit) {
    val current by rememberUpdatedState(onChange)
    Box(
        Modifier
            .fillMaxWidth()
            .height(64.dp)
            .clip(RoundedCornerShape(32.dp))
            .background(Track)
            .pointerInput(min, max) {
                detectTapGestures { o -> current((o.x / size.width).coerceIn(min, max)) }
            }
            .pointerInput(min, max) {
                detectHorizontalDragGestures(
                    onDragStart = { o -> current((o.x / size.width).coerceIn(min, max)) },
                    onHorizontalDrag = { change, _ ->
                        change.consume()
                        current((change.position.x / size.width).coerceIn(min, max))
                    },
                )
            },
    ) {
        Box(Modifier.fillMaxHeight().fillMaxWidth(value.coerceIn(0.02f, 1f)).background(Amber)) {
            Box(
                Modifier.align(Alignment.CenterEnd).padding(end = 12.dp).size(6.dp, 32.dp)
                    .clip(RoundedCornerShape(3.dp)).background(OnAmber)
            )
        }
        Icon(
            Icons.Filled.BrightnessLow, null,
            Modifier.align(Alignment.CenterStart).padding(start = 22.dp).size(24.dp),
            tint = if (value > 0.2f) OnAmber else Muted,
        )
    }
}
