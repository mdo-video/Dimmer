package com.mdovideo.dimmer

import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SunScheduleTest {
    @Test fun tramontoDiRomaADicembre() {
        val t = Sun.sunset(LocalDate.of(2026, 12, 15), 41.9, 12.5, ZoneId.of("Europe/Rome"))
        assertNotNull(t)
        val minutes = t!!.hour * 60 + t.minute
        assertTrue("tramonto $t", minutes in (16 * 60 + 30)..(16 * 60 + 48))
    }

    @Test fun finestraNellaStessaGiornata() {
        val s = LocalTime.of(9, 0)
        val e = LocalTime.of(17, 0)
        assertTrue(Schedule.isInside(LocalTime.of(12, 0), s, e))
        assertEquals(false, Schedule.isInside(LocalTime.of(18, 0), s, e))
    }

    @Test fun finestraCheSuperaLaMezzanotte() {
        val s = LocalTime.of(22, 0)
        val e = LocalTime.of(7, 0)
        assertTrue(Schedule.isInside(LocalTime.of(23, 30), s, e))
        assertTrue(Schedule.isInside(LocalTime.of(3, 0), s, e))
        assertEquals(false, Schedule.isInside(LocalTime.of(12, 0), s, e))
    }
}
