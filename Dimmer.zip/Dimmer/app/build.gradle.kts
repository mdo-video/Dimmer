plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// Il numero dell'esecuzione della CI (workflow). In locale vale 1. È anche il tag della release: "v<versionCode>".
val buildNumber = (System.getenv("VERSION_CODE") ?: "1").toInt()
val majorVersion = 1
val buildBase = 1

android {
    namespace = "com.mdovideo.dimmer"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.mdovideo.dimmer"
        minSdk = 26
        targetSdk = 35
        versionCode = buildNumber
        versionName = "$majorVersion.${(buildNumber - buildBase).coerceAtLeast(0)}"
    }

    // Firma fissa: serve perché Android accetti un aggiornamento sopra la versione già installata.
    signingConfigs {
        create("shared") {
            storeFile = file("dimmer.jks")
            storePassword = "dimmer"
            keyAlias = "dimmer"
            keyPassword = "dimmer"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("shared")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("shared")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
